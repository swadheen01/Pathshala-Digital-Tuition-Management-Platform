import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';
import '../../../core/utils/validators.dart';
import '../../../providers/auth_provider.dart';

/// Second step of the auth flow: user enters the 6-digit code sent
/// to their email (spec §1: role-based authentication via OTP).
///
/// Expects the email to be passed via GoRouter's `extra` param:
///   context.push(RouteNames.otpVerification, extra: email);
class OtpVerificationScreen extends ConsumerStatefulWidget {
  const OtpVerificationScreen({super.key, required this.email});

  final String email;

  @override
  ConsumerState<OtpVerificationScreen> createState() =>
      _OtpVerificationScreenState();
}

class _OtpVerificationScreenState
    extends ConsumerState<OtpVerificationScreen> {
  final _formKey = GlobalKey<FormState>();
  final _otpController = TextEditingController();

  @override
  void dispose() {
    _otpController.dispose();
    super.dispose();
  }

  Future<void> _handleVerify() async {
    if (!_formKey.currentState!.validate()) return;

    final success = await ref.read(authControllerProvider.notifier).verifyEmailOtp(
          email: widget.email,
          token: _otpController.text.trim(),
        );

    if (!mounted) return;

    if (!success) {
      final authState = ref.read(authControllerProvider);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Invalid or expired code: ${authState.error}')),
      );
      return;
    }

    // Refresh the profile provider now that we're authenticated.
    ref.invalidate(currentProfileProvider);

    final profile = await ref.read(currentProfileProvider.future);
    if (!mounted) return;

    // No name/role saved yet → send to profile setup (spec §1).
    if (profile == null || profile.fullName.isEmpty) {
      context.go(RouteNames.roleSelection);
    } else {
      // Route to the right dashboard based on role.
      switch (profile.role.name) {
        case 'teacher':
          context.go(RouteNames.teacherDashboard);
        case 'admin':
          context.go(RouteNames.adminDashboard);
        case 'parent':
          context.go(RouteNames.parentDashboard);
        default:
          context.go(RouteNames.studentDashboard);
      }
    }
  }

  Future<void> _handleResend() async {
    await ref.read(authControllerProvider.notifier).sendEmailOtp(widget.email);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Code resent')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authControllerProvider);
    final isLoading = authState.isLoading;

    return Scaffold(
      appBar: AppBar(title: const Text('Verify Code')),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: Form(
            key: _formKey,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  'Enter the 6-digit code sent to',
                  style: Theme.of(context).textTheme.bodyMedium,
                  textAlign: TextAlign.center,
                ),
                Text(
                  widget.email,
                  style: Theme.of(context)
                      .textTheme
                      .bodyMedium
                      ?.copyWith(fontWeight: FontWeight.bold),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 32),
                TextFormField(
                  controller: _otpController,
                  keyboardType: TextInputType.number,
                  maxLength: 6,
                  textAlign: TextAlign.center,
                  style: const TextStyle(fontSize: 24, letterSpacing: 8),
                  decoration: const InputDecoration(counterText: ''),
                  validator: Validators.otp,
                  enabled: !isLoading,
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: isLoading ? null : _handleVerify,
                  child: isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('Verify'),
                ),
                const SizedBox(height: 12),
                TextButton(
                  onPressed: isLoading ? null : _handleResend,
                  child: const Text("Didn't get a code? Resend"),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
