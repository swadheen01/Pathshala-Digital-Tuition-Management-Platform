import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';
import '../../../providers/room_provider.dart';

/// Hub screen for a single room: shows join code + quick links to
/// every teacher feature scoped to this room (spec §2.1–§2.8).
class RoomDetailScreen extends ConsumerWidget {
  const RoomDetailScreen({super.key, required this.roomId});

  final String roomId;

  String _path(String template) => template.replaceFirst(':roomId', roomId);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final roomAsync = ref.watch(roomByIdProvider(roomId));

    return Scaffold(
      appBar: AppBar(title: const Text('Room')),
      body: roomAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load room: $err')),
        data: (room) {
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(room.name,
                          style: Theme.of(context).textTheme.titleLarge),
                      if (room.subject != null) Text(room.subject!),
                      const SizedBox(height: 12),
                      Row(
                        children: [
                          const Text('Join code: '),
                          Text(
                            room.joinCode,
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                              letterSpacing: 2,
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              _FeatureTile(
                icon: Icons.people_outline,
                label: 'Students',
                onTap: () => context.push(_path(RouteNames.studentList)),
              ),
              _FeatureTile(
                icon: Icons.event_available_outlined,
                label: 'Attendance',
                onTap: () => context.push(_path(RouteNames.attendance)),
              ),
              _FeatureTile(
                icon: Icons.calendar_month_outlined,
                label: 'Class Schedule',
                onTap: () => context.push(_path(RouteNames.roomSchedule)),
              ),
              _FeatureTile(
                icon: Icons.chat_bubble_outline,
                label: 'Messages & Polls',
                onTap: () => context.push(_path(RouteNames.messaging)),
              ),
              _FeatureTile(
                icon: Icons.payments_outlined,
                label: 'Payments & Dues',
                onTap: () => context.push(_path(RouteNames.payments)),
              ),
              _FeatureTile(
                icon: Icons.assignment_outlined,
                label: 'Assignments',
                onTap: () => context.push(_path(RouteNames.assignments)),
              ),
              _FeatureTile(
                icon: Icons.bar_chart_outlined,
                label: 'Exams & Leaderboard',
                onTap: () => context.push(_path(RouteNames.exams)),
              ),
              _FeatureTile(
                icon: Icons.family_restroom_outlined,
                label: 'Parent Access',
                onTap: () => context.push(_path(RouteNames.parentAccess)),
              ),
            ],
          );
        },
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon),
        title: Text(label),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
