import 'package:supabase_flutter/supabase_flutter.dart';

/// Central place for Supabase connection details and initialization.
///
/// SECURITY NOTE:
/// Never hardcode the URL/anon key directly if this repo will be public.
/// Pass them at build/run time instead:
///
///   flutter run \
///     --dart-define=SUPABASE_URL=https://xxxx.supabase.co \
///     --dart-define=SUPABASE_ANON_KEY=your-anon-key
///
/// For quick local testing you CAN hardcode temporarily below, but
/// switch to --dart-define before committing to version control.
class SupabaseConfig {
  SupabaseConfig._();

  static const String supabaseUrl = String.fromEnvironment(
    'SUPABASE_URL',
    defaultValue: 'https://YOUR-PROJECT-REF.supabase.co',
  );

  static const String supabaseAnonKey = String.fromEnvironment(
    'SUPABASE_ANON_KEY',
    defaultValue: 'YOUR-ANON-KEY',
  );

  /// Call this once in main() before runApp().
  static Future<void> initialize() async {
    await Supabase.initialize(
      url: supabaseUrl,
      anonKey: supabaseAnonKey,
      // debug: true, // uncomment while developing to see auth/network logs
    );
  }

  /// Shortcut accessor used throughout the app's service layer.
  static SupabaseClient get client => Supabase.instance.client;
}
