import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';
import '../../../providers/parent_provider.dart';

/// Parent's home screen: lists linked children, tapping one shows
/// which rooms they're in (spec §2.8 — read-only view).
class ParentDashboardScreen extends ConsumerWidget {
  const ParentDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final childrenAsync = ref.watch(myChildrenProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('My Children')),
      body: childrenAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load: $err')),
        data: (children) {
          if (children.isEmpty) {
            return const Center(
              child: Text(
                "No children linked yet.\nAsk your child's teacher to grant access.",
                textAlign: TextAlign.center,
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: children.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final child = children[index];
              return Card(
                child: ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(child.studentName ?? 'Unknown'),
                  trailing: const Icon(Icons.chevron_right),
                  onTap: () => _showRoomPicker(context, ref, child.studentId,
                      child.studentName ?? 'Child'),
                ),
              );
            },
          );
        },
      ),
    );
  }

  Future<void> _showRoomPicker(
    BuildContext context,
    WidgetRef ref,
    String studentId,
    String studentName,
  ) async {
    final rooms = await ref.read(childRoomsProvider(studentId).future);

    if (!context.mounted) return;

    if (rooms.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('$studentName is not in any rooms yet.')),
      );
      return;
    }

    await showModalBottomSheet(
      context: context,
      builder: (context) => SafeArea(
        child: ListView(
          shrinkWrap: true,
          children: rooms
              .map((room) => ListTile(
                    title: Text(room.name),
                    subtitle:
                        room.subject != null ? Text(room.subject!) : null,
                    onTap: () {
                      Navigator.pop(context);
                      context.push(
                        RouteNames.childAttendance
                            .replaceFirst(':childId', studentId),
                        extra: room.id,
                      );
                    },
                  ))
              .toList(),
        ),
      ),
    );
  }
}
