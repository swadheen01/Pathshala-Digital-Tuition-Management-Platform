import 'package:equatable/equatable.dart';

/// A Tuition Room, created by a teacher (spec §2.1).
/// Students join using `joinCode`. Mirrors the `rooms` table.
class RoomModel extends Equatable {
  const RoomModel({
    required this.id,
    required this.teacherId,
    required this.name,
    required this.joinCode,
    this.subject,
    this.description,
    this.chatEnabled = false,
    this.leaderboardEnabled = false,
    this.classDays = const [],
    this.createdAt,
  });

  final String id;
  final String teacherId;
  final String name;
  final String joinCode; // short unique code students enter to join (§2.1)
  final String? subject;
  final String? description;
  final bool chatEnabled; // teacher-controlled toggle (§2.2)
  final bool leaderboardEnabled; // teacher-controlled toggle (§2.7)

  /// Weekday ints, 1 (Sunday) – 7 (Saturday), matching spec §2.5.
  /// Attendance can only be marked on these days.
  final List<int> classDays;

  final DateTime? createdAt;

  factory RoomModel.fromJson(Map<String, dynamic> json) {
    return RoomModel(
      id: json['id'] as String,
      teacherId: json['teacher_id'] as String,
      name: json['name'] as String,
      joinCode: json['join_code'] as String,
      subject: json['subject'] as String?,
      description: json['description'] as String?,
      chatEnabled: json['chat_enabled'] as bool? ?? false,
      leaderboardEnabled: json['leaderboard_enabled'] as bool? ?? false,
      classDays: (json['class_days'] as List<dynamic>?)
              ?.map((e) => e as int)
              .toList() ??
          const [],
      createdAt: json['created_at'] != null
          ? DateTime.tryParse(json['created_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'teacher_id': teacherId,
      'name': name,
      'join_code': joinCode,
      'subject': subject,
      'description': description,
      'chat_enabled': chatEnabled,
      'leaderboard_enabled': leaderboardEnabled,
      'class_days': classDays,
    };
  }

  RoomModel copyWith({
    String? name,
    String? subject,
    String? description,
    bool? chatEnabled,
    bool? leaderboardEnabled,
    List<int>? classDays,
  }) {
    return RoomModel(
      id: id,
      teacherId: teacherId,
      name: name ?? this.name,
      joinCode: joinCode,
      subject: subject ?? this.subject,
      description: description ?? this.description,
      chatEnabled: chatEnabled ?? this.chatEnabled,
      leaderboardEnabled: leaderboardEnabled ?? this.leaderboardEnabled,
      classDays: classDays ?? this.classDays,
      createdAt: createdAt,
    );
  }

  @override
  List<Object?> get props => [
        id,
        teacherId,
        name,
        joinCode,
        subject,
        description,
        chatEnabled,
        leaderboardEnabled,
        classDays,
      ];
}
