import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../providers/room_provider.dart';

const _weekdayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/// Edit which weekdays this room holds class (spec §2.5).
/// Attendance dates are restricted to these days.
class RoomScheduleScreen extends ConsumerStatefulWidget {
  const RoomScheduleScreen({super.key, required this.roomId});

  final String roomId;

  @override
  ConsumerState<RoomScheduleScreen> createState() =>
      _RoomScheduleScreenState();
}

class _RoomScheduleScreenState extends ConsumerState<RoomScheduleScreen> {
  Set<int>? _selectedDays;

  Future<void> _save() async {
    if (_selectedDays == null) return;
    final success = await ref
        .read(roomControllerProvider.notifier)
        .updateRoomSettings(widget.roomId, classDays: _selectedDays!.toList()..sort());

    if (!mounted) return;
    ref.invalidate(roomByIdProvider(widget.roomId));
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? 'Schedule updated' : 'Failed to update')),
    );
  }

  @override
  Widget build(BuildContext context) {
    final roomAsync = ref.watch(roomByIdProvider(widget.roomId));
    final controllerState = ref.watch(roomControllerProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Class Schedule')),
      body: roomAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load: $err')),
        data: (room) {
          _selectedDays ??= room.classDays.toSet();

          return Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text('Select class days',
                    style: Theme.of(context).textTheme.titleMedium),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 8,
                  children: List.generate(7, (index) {
                    final weekday = index + 1;
                    final selected = _selectedDays!.contains(weekday);
                    return FilterChip(
                      label: Text(_weekdayLabels[index]),
                      selected: selected,
                      onSelected: (value) {
                        setState(() {
                          if (value) {
                            _selectedDays!.add(weekday);
                          } else {
                            _selectedDays!.remove(weekday);
                          }
                        });
                      },
                    );
                  }),
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: controllerState.isLoading ? null : _save,
                  child: const Text('Save'),
                ),
              ],
            ),
          );
        },
      ),
    );
  }
}
