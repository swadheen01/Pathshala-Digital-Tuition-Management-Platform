import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';
import '../../../models/room_model.dart';
import '../../../providers/room_provider.dart';

/// Student's home screen: two sections, School and Tuition (spec §3 —
/// "School classes can be added later using the same core feature set").
/// For now, since school-specific fields don't exist yet, both tabs
/// show the same joined-rooms list; this is the seam where a `roomType`
/// column would be added to distinguish them later without touching
/// any other screen.
class SchoolTuitionTabsScreen extends ConsumerWidget {
  const SchoolTuitionTabsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final roomsAsync = ref.watch(studentRoomsProvider);

    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Pathshala'),
          actions: [
            IconButton(
              icon: const Icon(Icons.video_library_outlined),
              tooltip: 'Content',
              onPressed: () => context.push(RouteNames.contentFeed),
            ),
          ],
          bottom: const TabBar(
            tabs: [Tab(text: 'Tuition'), Tab(text: 'School')],
          ),
        ),
        body: TabBarView(
          children: [
            _RoomsTab(roomsAsync: roomsAsync),
            _RoomsTab(roomsAsync: roomsAsync), // seam for future school split
          ],
        ),
        floatingActionButton: FloatingActionButton(
          onPressed: () => context.push(RouteNames.joinRoom),
          child: const Icon(Icons.add),
        ),
      ),
    );
  }
}

class _RoomsTab extends StatelessWidget {
  const _RoomsTab({required this.roomsAsync});
  final AsyncValue<List<RoomModel>> roomsAsync;

  @override
  Widget build(BuildContext context) {
    return roomsAsync.when(
      loading: () => const Center(child: CircularProgressIndicator()),
      error: (err, _) => Center(child: Text('Failed to load: $err')),
      data: (rooms) {
        if (rooms.isEmpty) {
          return const Center(
            child: Text('No rooms yet.\nTap + to join one with a code.',
                textAlign: TextAlign.center),
          );
        }
        return ListView.separated(
          padding: const EdgeInsets.all(16),
          itemCount: rooms.length,
          separatorBuilder: (_, __) => const SizedBox(height: 8),
          itemBuilder: (context, index) {
            final room = rooms[index];
            return Card(
              child: ListTile(
                title: Text(room.name),
                subtitle: room.subject != null ? Text(room.subject!) : null,
                trailing: const Icon(Icons.chevron_right),
                onTap: () => context.push(
                  RouteNames.roomFeed.replaceFirst(':roomId', room.id),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
