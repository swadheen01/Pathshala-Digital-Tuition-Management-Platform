import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../providers/room_provider.dart';

/// Teacher's roster of students in a room (spec §2.1: Name, Roll Number, Email).
class StudentListScreen extends ConsumerWidget {
  const StudentListScreen({super.key, required this.roomId});

  final String roomId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final membersAsync = ref.watch(roomMembersProvider(roomId));

    return Scaffold(
      appBar: AppBar(title: const Text('Students')),
      body: membersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load: $err')),
        data: (members) {
          if (members.isEmpty) {
            return const Center(
              child: Text('No students yet.\nShare the join code to add students.',
                  textAlign: TextAlign.center),
            );
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: members.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final m = members[index];
              return Card(
                child: ListTile(
                  leading: CircleAvatar(
                    child: Text(m.studentName.isNotEmpty
                        ? m.studentName[0].toUpperCase()
                        : '?'),
                  ),
                  title: Text(m.studentName),
                  subtitle: Text([
                    if (m.member.rollNumber != null)
                      'Roll: ${m.member.rollNumber}',
                    if (m.studentEmail != null) m.studentEmail!,
                  ].join(' · ')),
                  trailing: IconButton(
                    icon: const Icon(Icons.person_remove_outlined),
                    onPressed: () async {
                      final confirm = await showDialog<bool>(
                        context: context,
                        builder: (context) => AlertDialog(
                          title: const Text('Remove student?'),
                          content: Text(
                              'Remove ${m.studentName} from this room?'),
                          actions: [
                            TextButton(
                              onPressed: () => Navigator.pop(context, false),
                              child: const Text('Cancel'),
                            ),
                            TextButton(
                              onPressed: () => Navigator.pop(context, true),
                              child: const Text('Remove'),
                            ),
                          ],
                        ),
                      );
                      if (confirm == true) {
                        await ref
                            .read(roomServiceProvider)
                            .removeMember(roomId, m.member.studentId);
                        ref.invalidate(roomMembersProvider(roomId));
                      }
                    },
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
