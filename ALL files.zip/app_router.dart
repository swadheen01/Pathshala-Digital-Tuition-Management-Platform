import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../features/auth/screens/login_screen.dart';
import '../../features/auth/screens/otp_verification_screen.dart';
import '../../features/auth/screens/profile_setup_screen.dart';
import '../../features/auth/screens/role_selection_screen.dart';
import '../../features/admin/screens/add_content_screen.dart';
import '../../features/admin/screens/analytics_screen.dart';
import '../../features/admin/screens/manage_content_screen.dart';
import '../../features/admin/screens/manage_students_screen.dart';
import '../../features/admin/screens/manage_teachers_screen.dart';
import '../../features/parent/screens/child_attendance_screen.dart';
import '../../features/parent/screens/child_payments_screen.dart';
import '../../features/parent/screens/child_performance_screen.dart';
import '../../features/shared/screens/home_shell_screen.dart';
import '../../features/shared/screens/messaging_screen.dart';
import '../../features/shared/screens/profile_screen.dart';
import '../../features/shared/screens/settings_screen.dart';
import '../../features/student/screens/content_feed_screen.dart';
import '../../features/student/screens/content_search_screen.dart';
import '../../features/shared/screens/notifications_screen.dart';
import '../../features/student/screens/assignment_submission_screen.dart';
import '../../features/student/screens/attendance_view_screen.dart';
import '../../features/student/screens/exam_performance_screen.dart';
import '../../features/student/screens/join_room_screen.dart';
import '../../features/student/screens/leaderboard_screen.dart';
import '../../features/student/screens/room_feed_screen.dart';
import '../../features/student/screens/student_assignments_screen.dart';
import '../../features/teacher/screens/assignments_screen.dart';
import '../../features/teacher/screens/attendance_screen.dart';
import '../../features/teacher/screens/attendance_summary_screen.dart';
import '../../features/teacher/screens/create_assignment_screen.dart';
import '../../features/teacher/screens/create_poll_screen.dart';
import '../../features/teacher/screens/create_room_screen.dart';
import '../../features/teacher/screens/exams_screen.dart';
import '../../features/teacher/screens/leaderboard_settings_screen.dart';
import '../../features/teacher/screens/parent_access_screen.dart';
import '../../features/teacher/screens/payment_history_export_screen.dart';
import '../../features/teacher/screens/payments_screen.dart';
import '../../features/teacher/screens/record_exam_score_screen.dart';
import '../../features/teacher/screens/record_payment_screen.dart';
import '../../features/teacher/screens/review_submissions_screen.dart';
import '../../features/teacher/screens/payments_screen.dart';
import '../../features/teacher/screens/room_detail_screen.dart';
import '../../features/teacher/screens/room_list_screen.dart';
import '../../features/teacher/screens/room_schedule_screen.dart';
import '../../features/teacher/screens/student_list_screen.dart';
import '../../models/user_model.dart';
import 'route_names.dart';

/// Temporary placeholder screen so routes compile before real screens exist.
/// Once a real screen file is built (e.g. LoginScreen), swap it in below
/// and delete the corresponding _Placeholder call.
class _PlaceholderScreen extends StatelessWidget {
  const _PlaceholderScreen(this.label);
  final String label;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(label)),
      body: Center(
        child: Text(
          '$label\n(screen not built yet)',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleMedium,
        ),
      ),
    );
  }
}

/// Riverpod provider so the router can later react to auth state
/// (e.g. redirect to /login if session is null). Wire that up once
/// auth_provider.dart exists.
final appRouterProvider = Provider<GoRouter>((ref) {
  return GoRouter(
    initialLocation: RouteNames.splash,
    debugLogDiagnostics: true,

    // TODO once auth_provider.dart exists:
    // redirect: (context, state) {
    //   final session = ref.read(authProvider).session;
    //   final loggingIn = state.matchedLocation == RouteNames.login;
    //   if (session == null && !loggingIn) return RouteNames.login;
    //   if (session != null && loggingIn) return RouteNames.teacherDashboard;
    //   return null;
    // },

    routes: [
      // --- Onboarding / Auth ---
      GoRoute(
        path: RouteNames.splash,
        builder: (context, state) => const _PlaceholderScreen('Splash'),
      ),
      GoRoute(
        path: RouteNames.languageSelect,
        builder: (context, state) =>
            const _PlaceholderScreen('Language Select'),
      ),
      GoRoute(
        path: RouteNames.login,
        builder: (context, state) => const LoginScreen(),
      ),
      GoRoute(
        path: RouteNames.signup,
        builder: (context, state) => const _PlaceholderScreen('Sign Up'),
      ),
      GoRoute(
        path: RouteNames.otpVerification,
        builder: (context, state) {
          final email = state.extra as String? ?? '';
          return OtpVerificationScreen(email: email);
        },
      ),
      GoRoute(
        path: RouteNames.roleSelection,
        builder: (context, state) => const RoleSelectionScreen(),
      ),
      GoRoute(
        path: RouteNames.profileSetup,
        builder: (context, state) {
          final role = state.extra as UserRole? ?? UserRole.student;
          return ProfileSetupScreen(role: role);
        },
      ),

      // --- Shared ---
      GoRoute(
        path: RouteNames.calendar,
        builder: (context, state) => const _PlaceholderScreen('Calendar'),
      ),
      GoRoute(
        path: RouteNames.notifications,
        builder: (context, state) => const NotificationsScreen(),
      ),
      GoRoute(
        path: RouteNames.settings,
        builder: (context, state) => const SettingsScreen(),
      ),
      GoRoute(
        path: RouteNames.profile,
        builder: (context, state) => const ProfileScreen(),
      ),

      // --- Teacher ---
      GoRoute(
        path: RouteNames.teacherDashboard,
        builder: (context, state) => const HomeShellScreen(),
      ),
      GoRoute(
        path: RouteNames.roomList,
        builder: (context, state) => const RoomListScreen(),
      ),
      GoRoute(
        path: RouteNames.createRoom,
        builder: (context, state) => const CreateRoomScreen(),
      ),
      GoRoute(
        path: RouteNames.roomDetail,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return RoomDetailScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.attendance,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return AttendanceScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.attendanceSummary,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return AttendanceSummaryScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.studentList,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return StudentListScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.roomSchedule,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return RoomScheduleScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.messaging,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return MessagingScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.createPoll,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return CreatePollScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.payments,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return PaymentsScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.recordPayment,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return RecordPaymentScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.paymentHistoryExport,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return PaymentHistoryExportScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.assignments,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return AssignmentsScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.createAssignment,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return CreateAssignmentScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.reviewSubmissions,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          final assignmentId = state.pathParameters['assignmentId']!;
          return ReviewSubmissionsScreen(
            roomId: roomId,
            assignmentId: assignmentId,
          );
        },
      ),
      GoRoute(
        path: RouteNames.exams,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return ExamsScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.recordExamScore,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          final examId = state.pathParameters['examId']!;
          return RecordExamScoreScreen(roomId: roomId, examId: examId);
        },
      ),
      GoRoute(
        path: RouteNames.leaderboardSettings,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return LeaderboardSettingsScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.parentAccess,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return ParentAccessScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.payments,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return PaymentsScreen(roomId: roomId);
        },
      ),

      // --- Student ---
      GoRoute(
        path: RouteNames.studentDashboard,
        builder: (context, state) => const HomeShellScreen(),
      ),
      GoRoute(
        path: RouteNames.joinRoom,
        builder: (context, state) => const JoinRoomScreen(),
      ),
      GoRoute(
        path: RouteNames.roomFeed,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return RoomFeedScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.studentAssignments,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return StudentAssignmentsScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.examPerformance,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return ExamPerformanceScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.leaderboard,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return LeaderboardScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.contentFeed,
        builder: (context, state) => const ContentFeedScreen(),
      ),
      GoRoute(
        path: RouteNames.contentSearch,
        builder: (context, state) => const ContentSearchScreen(),
      ),
      GoRoute(
        path: RouteNames.attendanceView,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          return AttendanceViewScreen(roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.assignmentSubmission,
        builder: (context, state) {
          final roomId = state.pathParameters['roomId']!;
          final assignmentId = state.pathParameters['assignmentId']!;
          return AssignmentSubmissionScreen(
            roomId: roomId,
            assignmentId: assignmentId,
          );
        },
      ),

      // --- Admin ---
      GoRoute(
        path: RouteNames.adminDashboard,
        builder: (context, state) => const HomeShellScreen(),
      ),
      GoRoute(
        path: RouteNames.manageTeachers,
        builder: (context, state) => const ManageTeachersScreen(),
      ),
      GoRoute(
        path: RouteNames.manageStudents,
        builder: (context, state) => const ManageStudentsScreen(),
      ),
      GoRoute(
        path: RouteNames.manageContent,
        builder: (context, state) => const ManageContentScreen(),
      ),
      GoRoute(
        path: RouteNames.addContent,
        builder: (context, state) => const AddContentScreen(),
      ),
      GoRoute(
        path: RouteNames.analytics,
        builder: (context, state) => const AnalyticsScreen(),
      ),

      // --- Parent ---
      GoRoute(
        path: RouteNames.parentDashboard,
        builder: (context, state) => const HomeShellScreen(),
      ),
      GoRoute(
        path: RouteNames.childAttendance,
        builder: (context, state) {
          final childId = state.pathParameters['childId']!;
          final roomId = state.extra as String? ?? '';
          return ChildAttendanceScreen(childId: childId, roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.childPayments,
        builder: (context, state) {
          final childId = state.pathParameters['childId']!;
          final roomId = state.extra as String? ?? '';
          return ChildPaymentsScreen(childId: childId, roomId: roomId);
        },
      ),
      GoRoute(
        path: RouteNames.childPerformance,
        builder: (context, state) {
          final childId = state.pathParameters['childId']!;
          final roomId = state.extra as String? ?? '';
          return ChildPerformanceScreen(childId: childId, roomId: roomId);
        },
      ),
    ],
  );
});
