import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'app.dart';
import 'core/config/supabase_config.dart';
import 'services/offline_sync_service.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Set up the Supabase client (auth, database, storage, realtime).
  await SupabaseConfig.initialize();

  // Auto-flush any attendance marked while offline as soon as
  // connectivity returns (spec §2.3).
  OfflineSyncService().listenForConnectivity();

  runApp(
    // ProviderScope makes Riverpod providers available to the whole tree.
    const ProviderScope(
      child: PathshalaApp(),
    ),
  );
}
