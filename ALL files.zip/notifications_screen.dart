import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../models/notification_model.dart';
import '../../../providers/notification_provider.dart';

/// Notifications inbox — shown to every role (spec §1, §3: "Students
/// can view all notifications sent by the teacher (auto + custom)").
class NotificationsScreen extends ConsumerWidget {
  const NotificationsScreen({super.key});

  IconData _iconFor(NotificationType type) {
    switch (type) {
      case NotificationType.message:
        return Icons.chat_bubble_outline;
      case NotificationType.poll:
        return Icons.poll_outlined;
      case NotificationType.content:
        return Icons.video_library_outlined;
      case NotificationType.attendance:
        return Icons.event_available_outlined;
      case NotificationType.assignment:
        return Icons.assignment_outlined;
      case NotificationType.examResult:
        return Icons.bar_chart_outlined;
      case NotificationType.paymentDue:
        return Icons.payment_outlined;
      case NotificationType.paymentReceived:
        return Icons.check_circle_outline;
      case NotificationType.custom:
        return Icons.notifications_outlined;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notificationsAsync = ref.watch(myNotificationsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notifications'),
        actions: [
          TextButton(
            onPressed: () =>
                ref.read(notificationControllerProvider.notifier).markAllAsRead(),
            child: const Text('Mark all read'),
          ),
        ],
      ),
      body: notificationsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load: $err')),
        data: (notifications) {
          if (notifications.isEmpty) {
            return const Center(child: Text('No notifications yet.'));
          }
          return ListView.separated(
            itemCount: notifications.length,
            separatorBuilder: (_, __) => const Divider(height: 1),
            itemBuilder: (context, index) {
              final n = notifications[index];
              return ListTile(
                leading: Icon(
                  _iconFor(n.type),
                  color: n.isUnread
                      ? Theme.of(context).colorScheme.primary
                      : Theme.of(context).colorScheme.outline,
                ),
                title: Text(
                  n.title,
                  style: TextStyle(
                    fontWeight: n.isUnread ? FontWeight.bold : FontWeight.normal,
                  ),
                ),
                subtitle: n.body != null ? Text(n.body!) : null,
                trailing: n.createdAt != null
                    ? Text(
                        '${n.createdAt!.day}/${n.createdAt!.month}',
                        style: Theme.of(context).textTheme.bodySmall,
                      )
                    : null,
                onTap: () {
                  if (n.isUnread) {
                    ref
                        .read(notificationControllerProvider.notifier)
                        .markAsRead(n.id);
                  }
                  // Deep-link into n.roomId here once shared room routing
                  // helpers are in place — left as a follow-up.
                },
              );
            },
          );
        },
      ),
    );
  }
}
