import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';

/// Admin's home screen — hub linking to teacher/student/content
/// management and the analytics dashboard (spec §4).
class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Admin')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          _AdminTile(
            icon: Icons.school_outlined,
            label: 'Teachers',
            onTap: () => context.push(RouteNames.manageTeachers),
          ),
          _AdminTile(
            icon: Icons.backpack_outlined,
            label: 'Students',
            onTap: () => context.push(RouteNames.manageStudents),
          ),
          _AdminTile(
            icon: Icons.video_library_outlined,
            label: 'Content',
            onTap: () => context.push(RouteNames.manageContent),
          ),
          _AdminTile(
            icon: Icons.analytics_outlined,
            label: 'Analytics',
            onTap: () => context.push(RouteNames.analytics),
          ),
        ],
      ),
    );
  }
}

class _AdminTile extends StatelessWidget {
  const _AdminTile({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 12),
      child: ListTile(
        leading: Icon(icon, size: 28),
        title: Text(label, style: Theme.of(context).textTheme.titleMedium),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
