import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../../core/utils/validators.dart';
import '../../../providers/auth_provider.dart';
import '../../../services/auth_service.dart';

/// Profile view/edit screen — shared across all roles. Shows the
/// fields captured at signup (spec §1: name, class/grade, institution)
/// and lets the user update them.
class ProfileScreen extends ConsumerStatefulWidget {
  const ProfileScreen({super.key});

  @override
  ConsumerState<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends ConsumerState<ProfileScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _classGradeController = TextEditingController();
  final _institutionController = TextEditingController();
  bool _prefilled = false;
  bool _saving = false;

  @override
  void dispose() {
    _nameController.dispose();
    _classGradeController.dispose();
    _institutionController.dispose();
    super.dispose();
  }

  Future<void> _handleSave() async {
    if (!_formKey.currentState!.validate()) return;

    setState(() => _saving = true);

    final profile = ref.read(currentProfileProvider).valueOrNull;
    if (profile == null) return;

    try {
      await AuthService().completeProfile(
        fullName: _nameController.text.trim(),
        role: profile.role,
        classGrade: _classGradeController.text.trim().isEmpty
            ? null
            : _classGradeController.text.trim(),
        institution: _institutionController.text.trim().isEmpty
            ? null
            : _institutionController.text.trim(),
      );

      ref.invalidate(currentProfileProvider);

      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(const SnackBar(content: Text('Profile updated')));
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context)
          .showSnackBar(SnackBar(content: Text('Failed to save: $e')));
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final profileAsync = ref.watch(currentProfileProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Profile')),
      body: profileAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load: $err')),
        data: (profile) {
          if (profile != null && !_prefilled) {
            _nameController.text = profile.fullName;
            _classGradeController.text = profile.classGrade ?? '';
            _institutionController.text = profile.institution ?? '';
            _prefilled = true;
          }

          final isStudent = profile?.role.name == 'student';

          return SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Center(
                    child: CircleAvatar(
                      radius: 40,
                      child: Text(
                        profile?.fullName.isNotEmpty == true
                            ? profile!.fullName[0].toUpperCase()
                            : '?',
                        style: const TextStyle(fontSize: 28),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                  Text(
                    profile?.email ?? profile?.phone ?? '',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 8),
                  Chip(label: Text(profile?.role.name.toUpperCase() ?? '')),
                  const SizedBox(height: 24),
                  TextFormField(
                    controller: _nameController,
                    decoration: const InputDecoration(labelText: 'Full Name'),
                    validator: (v) => Validators.required(v, fieldName: 'Name'),
                    enabled: !_saving,
                  ),
                  if (isStudent) ...[
                    const SizedBox(height: 16),
                    TextFormField(
                      controller: _classGradeController,
                      decoration: const InputDecoration(labelText: 'Class / Grade'),
                      enabled: !_saving,
                    ),
                  ],
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: _institutionController,
                    decoration: const InputDecoration(
                      labelText: 'Institution (optional)',
                    ),
                    enabled: !_saving,
                  ),
                  const SizedBox(height: 24),
                  ElevatedButton(
                    onPressed: _saving ? null : _handleSave,
                    child: _saving
                        ? const SizedBox(
                            height: 20,
                            width: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Text('Save Changes'),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
