import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../core/routes/route_names.dart';
import '../../../models/content_model.dart';
import '../../../providers/content_provider.dart';

/// Student's home feed of curated content — YouTube/other links, some
/// general and some targeted to their class/grade (spec §3, §4).
///
/// NOTE: add `url_launcher: ^6.3.0` to pubspec.yaml — needed to open
/// content links, wasn't in the original dependency list.
class ContentFeedScreen extends ConsumerWidget {
  const ContentFeedScreen({super.key});

  Future<void> _openContent(
    BuildContext context,
    WidgetRef ref,
    ContentModel content,
  ) async {
    await ref.read(contentControllerProvider.notifier).logView(content.id);

    final uri = Uri.tryParse(content.url);
    if (uri != null && await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    } else if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Could not open this link')),
      );
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final feedAsync = ref.watch(studentContentFeedProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Content'),
        actions: [
          IconButton(
            icon: const Icon(Icons.search),
            onPressed: () => context.push(RouteNames.contentSearch),
          ),
        ],
      ),
      body: feedAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load: $err')),
        data: (items) {
          if (items.isEmpty) {
            return const Center(child: Text('No content available yet.'));
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) {
              final content = items[index];
              return Card(
                child: ListTile(
                  leading: const Icon(Icons.play_circle_outline, size: 32),
                  title: Text(content.title),
                  subtitle: Text(content.subject ?? content.description ?? ''),
                  onTap: () => _openContent(context, ref, content),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
