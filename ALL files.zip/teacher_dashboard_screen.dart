import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';
import '../../../providers/auth_provider.dart';
import '../../../providers/room_provider.dart';

/// Teacher's home screen — greeting, room count, and quick access to
/// the room list (spec §2, tab content within home_shell_screen.dart).
class TeacherDashboardScreen extends ConsumerWidget {
  const TeacherDashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final profileAsync = ref.watch(currentProfileProvider);
    final roomsAsync = ref.watch(teacherRoomsProvider);

    return Scaffold(
      appBar: AppBar(title: const Text('Pathshala')),
      body: RefreshIndicator(
        onRefresh: () async => ref.invalidate(teacherRoomsProvider),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            profileAsync.when(
              loading: () => const SizedBox.shrink(),
              error: (_, __) => const SizedBox.shrink(),
              data: (profile) => Text(
                'Welcome, ${profile?.fullName ?? 'Teacher'}',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
            ),
            const SizedBox(height: 24),
            roomsAsync.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (err, _) => Text('Failed to load rooms: $err'),
              data: (rooms) {
                return Card(
                  child: ListTile(
                    leading: const Icon(Icons.meeting_room_outlined),
                    title: Text('${rooms.length} Room${rooms.length == 1 ? '' : 's'}'),
                    subtitle: const Text('Tap to manage your tuition rooms'),
                    trailing: const Icon(Icons.chevron_right),
                    onTap: () => context.push(RouteNames.roomList),
                  ),
                );
              },
            ),
            const SizedBox(height: 16),
            Card(
              child: ListTile(
                leading: const Icon(Icons.add_circle_outline),
                title: const Text('Create a new room'),
                onTap: () => context.push(RouteNames.createRoom),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
