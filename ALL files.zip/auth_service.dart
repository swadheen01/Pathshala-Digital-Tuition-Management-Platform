import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/config/supabase_config.dart';
import '../models/user_model.dart';

/// Handles all Supabase Auth calls: OTP/email signup+login and
/// reading/writing the matching row in the `profiles` table (§1).
///
/// NOTE: This assumes a `profiles` table keyed by auth.users.id with
/// a Postgres trigger (or explicit insert here) that creates a row
/// on first signup. See supabase/migrations/0001_init.sql.
class AuthService {
  AuthService({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  GoTrueClient get _auth => _client.auth;

  /// Current logged-in session, or null if signed out.
  Session? get currentSession => _auth.currentSession;

  /// Stream of auth state changes — use this to drive router redirects.
  Stream<AuthState> get authStateChanges => _auth.onAuthStateChange;

  /// Step 1 of email OTP flow: sends a one-time code to the email.
  /// Supabase's `signInWithOtp` handles both signup and login —
  /// if the user doesn't exist yet, it creates one.
  Future<void> sendEmailOtp(String email) async {
    await _auth.signInWithOtp(email: email);
  }

  /// Step 2: verify the code the user received by email.
  Future<AuthResponse> verifyEmailOtp({
    required String email,
    required String token,
  }) async {
    return _auth.verifyOTP(
      email: email,
      token: token,
      type: OtpType.email,
    );
  }

  /// Phone OTP variant, if you prefer SMS-based signup over email.
  Future<void> sendPhoneOtp(String phone) async {
    await _auth.signInWithOtp(phone: phone);
  }

  Future<AuthResponse> verifyPhoneOtp({
    required String phone,
    required String token,
  }) async {
    return _auth.verifyOTP(
      phone: phone,
      token: token,
      type: OtpType.sms,
    );
  }

  Future<void> signOut() => _auth.signOut();

  /// Call right after first successful verification to create/complete
  /// the profile row: role, name, class/grade, institution (§1).
  Future<UserModel> completeProfile({
    required String fullName,
    required UserRole role,
    String? classGrade,
    String? institution,
  }) async {
    final userId = _auth.currentUser?.id;
    if (userId == null) {
      throw StateError('No authenticated user — cannot complete profile.');
    }

    final data = {
      'id': userId,
      'full_name': fullName,
      'role': role.name,
      'email': _auth.currentUser?.email,
      'phone': _auth.currentUser?.phone,
      'class_grade': classGrade,
      'institution': institution,
    };

    final response = await _client
        .from('profiles')
        .upsert(data)
        .select()
        .single();

    return UserModel.fromJson(response);
  }

  /// Fetch the profile row for the currently signed-in user.
  /// Returns null if the user hasn't completed profile setup yet.
  Future<UserModel?> fetchCurrentProfile() async {
    final userId = _auth.currentUser?.id;
    if (userId == null) return null;

    final response = await _client
        .from('profiles')
        .select()
        .eq('id', userId)
        .maybeSingle();

    if (response == null) return null;
    return UserModel.fromJson(response);
  }
}
