import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../../../providers/attendance_provider.dart';

/// Student's own attendance history/percentage in a room (spec §3).
class AttendanceViewScreen extends ConsumerWidget {
  const AttendanceViewScreen({super.key, required this.roomId});

  final String roomId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final studentId = Supabase.instance.client.auth.currentUser?.id ?? '';
    final historyAsync = ref.watch(
      studentAttendanceHistoryProvider((roomId: roomId, studentId: studentId)),
    );

    return Scaffold(
      appBar: AppBar(title: const Text('My Attendance')),
      body: historyAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load: $err')),
        data: (records) {
          if (records.isEmpty) {
            return const Center(child: Text('No attendance recorded yet.'));
          }

          final present = records.where((r) => r.present).length;
          final percentage = (present / records.length * 100).toStringAsFixed(1);

          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      children: [
                        Text('$percentage%',
                            style: Theme.of(context).textTheme.headlineMedium),
                        Text('$present / ${records.length} classes attended'),
                      ],
                    ),
                  ),
                ),
              ),
              Expanded(
                child: ListView.builder(
                  itemCount: records.length,
                  itemBuilder: (context, index) {
                    final r = records[index];
                    return ListTile(
                      leading: Icon(
                        r.present ? Icons.check_circle : Icons.cancel,
                        color: r.present ? Colors.green : Colors.red,
                      ),
                      title: Text('${r.date.day}/${r.date.month}/${r.date.year}'),
                      trailing: Text(r.present ? 'Present' : 'Absent'),
                    );
                  },
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
