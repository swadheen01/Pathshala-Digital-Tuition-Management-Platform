import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';
import '../../../models/payment_model.dart';
import '../../../providers/payment_provider.dart';

/// Teacher's dues overview for a room — amount paid, outstanding,
/// months overdue per student (spec §2.4).
class PaymentsScreen extends ConsumerWidget {
  const PaymentsScreen({super.key, required this.roomId});

  final String roomId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final duesAsync = ref.watch(duesSummaryProvider(roomId));

    return Scaffold(
      appBar: AppBar(
        title: const Text('Payments & Dues'),
        actions: [
          IconButton(
            icon: const Icon(Icons.file_download_outlined),
            tooltip: 'Export history',
            onPressed: () => context.push(
              RouteNames.paymentHistoryExport.replaceFirst(':roomId', roomId),
            ),
          ),
        ],
      ),
      body: duesAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load: $err')),
        data: (dues) {
          if (dues.isEmpty) {
            return const Center(child: Text('No students in this room yet.'));
          }

          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: dues.length,
            separatorBuilder: (_, __) => const SizedBox(height: 8),
            itemBuilder: (context, index) => _DuesCard(dues: dues[index]),
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => context.push(
          RouteNames.recordPayment.replaceFirst(':roomId', roomId),
        ),
        child: const Icon(Icons.add),
      ),
    );
  }
}

class _DuesCard extends StatelessWidget {
  const _DuesCard({required this.dues});

  final DuesSummary dues;

  @override
  Widget build(BuildContext context) {
    final overdue = dues.monthsOverdue > 0;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(dues.studentName,
                    style: Theme.of(context).textTheme.titleMedium),
                if (overdue)
                  Chip(
                    label: Text('${dues.monthsOverdue} mo overdue'),
                    backgroundColor:
                        Theme.of(context).colorScheme.errorContainer,
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text('Paid: ৳${dues.totalPaid.toStringAsFixed(0)}'),
                Text(
                  'Due: ৳${dues.outstanding.toStringAsFixed(0)}',
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    color: overdue ? Theme.of(context).colorScheme.error : null,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
