import 'package:equatable/equatable.dart';

/// Join table row: links a student to a room they've joined (spec §2.1).
/// A student can be in many rooms; a room can have many students.
class RoomMemberModel extends Equatable {
  const RoomMemberModel({
    required this.id,
    required this.roomId,
    required this.studentId,
    this.rollNumber,
    this.joinedAt,
  });

  final String id;
  final String roomId;
  final String studentId;
  final String? rollNumber; // per-room roll number (spec §2.1)
  final DateTime? joinedAt;

  factory RoomMemberModel.fromJson(Map<String, dynamic> json) {
    return RoomMemberModel(
      id: json['id'] as String,
      roomId: json['room_id'] as String,
      studentId: json['student_id'] as String,
      rollNumber: json['roll_number'] as String?,
      joinedAt: json['joined_at'] != null
          ? DateTime.tryParse(json['joined_at'] as String)
          : null,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'room_id': roomId,
      'student_id': studentId,
      'roll_number': rollNumber,
    };
  }

  @override
  List<Object?> get props => [id, roomId, studentId, rollNumber];
}

/// A room row joined with the student's profile info — convenient for
/// rendering student list screens (spec §2.1) without a second query.
class RoomMemberWithProfile extends Equatable {
  const RoomMemberWithProfile({
    required this.member,
    required this.studentName,
    this.studentEmail,
    this.avatarUrl,
  });

  final RoomMemberModel member;
  final String studentName;
  final String? studentEmail;
  final String? avatarUrl;

  factory RoomMemberWithProfile.fromJson(Map<String, dynamic> json) {
    final profile = json['profiles'] as Map<String, dynamic>? ?? const {};
    return RoomMemberWithProfile(
      member: RoomMemberModel.fromJson(json),
      studentName: profile['full_name'] as String? ?? 'Unknown',
      studentEmail: profile['email'] as String?,
      avatarUrl: profile['avatar_url'] as String?,
    );
  }

  @override
  List<Object?> get props => [member, studentName, studentEmail, avatarUrl];
}
