import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';
import '../../../core/utils/validators.dart';
import '../../../providers/room_provider.dart';

const _weekdayLabels = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];

/// Teacher creates a new tuition room, including its class-day
/// schedule (spec §2.1, §2.5). Attendance later can only be marked
/// on the days selected here.
class CreateRoomScreen extends ConsumerStatefulWidget {
  const CreateRoomScreen({super.key});

  @override
  ConsumerState<CreateRoomScreen> createState() => _CreateRoomScreenState();
}

class _CreateRoomScreenState extends ConsumerState<CreateRoomScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _subjectController = TextEditingController();
  final _descriptionController = TextEditingController();

  /// Selected weekdays, 1 (Sunday) – 7 (Saturday) matching spec §2.5.
  final Set<int> _selectedDays = {};

  @override
  void dispose() {
    _nameController.dispose();
    _subjectController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _handleCreate() async {
    if (!_formKey.currentState!.validate()) return;

    if (_selectedDays.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Select at least one class day')),
      );
      return;
    }

    final room = await ref.read(roomControllerProvider.notifier).createRoom(
          name: _nameController.text.trim(),
          subject: _subjectController.text.trim().isEmpty
              ? null
              : _subjectController.text.trim(),
          description: _descriptionController.text.trim().isEmpty
              ? null
              : _descriptionController.text.trim(),
          classDays: _selectedDays.toList()..sort(),
        );

    if (!mounted) return;

    if (room == null) {
      final state = ref.read(roomControllerProvider);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Failed to create room: ${state.error}')),
      );
      return;
    }

    ref.invalidate(teacherRoomsProvider);
    if (!mounted) return;

    // Show the join code before leaving, so the teacher can share it.
    await showDialog<void>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Room Created!'),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Share this join code with your students:'),
            const SizedBox(height: 12),
            Center(
              child: Text(
                room.joinCode,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  letterSpacing: 4,
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Done'),
          ),
        ],
      ),
    );

    if (!mounted) return;
    context.pop();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(roomControllerProvider);
    final isLoading = state.isLoading;

    return Scaffold(
      appBar: AppBar(title: const Text('Create Room')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Room Name',
                    hintText: 'e.g. Physics Batch A',
                  ),
                  validator: (v) => Validators.required(v, fieldName: 'Room name'),
                  enabled: !isLoading,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _subjectController,
                  decoration: const InputDecoration(
                    labelText: 'Subject (optional)',
                  ),
                  enabled: !isLoading,
                ),
                const SizedBox(height: 16),
                TextFormField(
                  controller: _descriptionController,
                  maxLines: 3,
                  decoration: const InputDecoration(
                    labelText: 'Description (optional)',
                  ),
                  enabled: !isLoading,
                ),
                const SizedBox(height: 24),
                Text('Class Days', style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 4),
                Text(
                  'Attendance can only be marked on selected days',
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 12),
                Wrap(
                  spacing: 8,
                  children: List.generate(7, (index) {
                    final weekday = index + 1; // 1=Sun..7=Sat
                    final selected = _selectedDays.contains(weekday);
                    return FilterChip(
                      label: Text(_weekdayLabels[index]),
                      selected: selected,
                      onSelected: isLoading
                          ? null
                          : (value) {
                              setState(() {
                                if (value) {
                                  _selectedDays.add(weekday);
                                } else {
                                  _selectedDays.remove(weekday);
                                }
                              });
                            },
                    );
                  }),
                ),
                const SizedBox(height: 32),
                ElevatedButton(
                  onPressed: isLoading ? null : _handleCreate,
                  child: isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('Create Room'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
