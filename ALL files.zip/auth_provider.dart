import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

import '../models/user_model.dart';
import '../services/auth_service.dart';

final authServiceProvider = Provider<AuthService>((ref) => AuthService());

/// Raw Supabase auth state stream — emits on sign-in, sign-out, token refresh.
final authStateChangesProvider = StreamProvider<AuthState>((ref) {
  return ref.watch(authServiceProvider).authStateChanges;
});

/// The current user's profile row (§1: role, class/grade, institution etc).
/// Null while loading, or if the user hasn't completed profile setup yet.
/// Re-fetches whenever the auth state changes (login/logout).
final currentProfileProvider = FutureProvider<UserModel?>((ref) async {
  // Re-run this provider whenever auth state changes.
  ref.watch(authStateChangesProvider);

  final authService = ref.watch(authServiceProvider);
  if (authService.currentSession == null) return null;

  return authService.fetchCurrentProfile();
});

/// Convenience bool for router redirects / gating screens.
final isLoggedInProvider = Provider<bool>((ref) {
  final session = ref.watch(authStateChangesProvider).valueOrNull?.session;
  return session != null || ref.watch(authServiceProvider).currentSession != null;
});

/// Controller for auth actions (OTP send/verify, sign out, profile setup).
/// Screens call methods on this via ref.read(authControllerProvider.notifier).
class AuthController extends StateNotifier<AsyncValue<void>> {
  AuthController(this._authService) : super(const AsyncData(null));

  final AuthService _authService;

  Future<void> sendEmailOtp(String email) async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _authService.sendEmailOtp(email));
  }

  Future<bool> verifyEmailOtp({
    required String email,
    required String token,
  }) async {
    state = const AsyncLoading();
    final result = await AsyncValue.guard(
      () => _authService.verifyEmailOtp(email: email, token: token),
    );
    state = result.hasError ? AsyncError(result.error!, result.stackTrace!) : const AsyncData(null);
    return !result.hasError;
  }

  Future<UserModel?> completeProfile({
    required String fullName,
    required UserRole role,
    String? classGrade,
    String? institution,
  }) async {
    state = const AsyncLoading();
    final result = await AsyncValue.guard(
      () => _authService.completeProfile(
        fullName: fullName,
        role: role,
        classGrade: classGrade,
        institution: institution,
      ),
    );
    state = result.hasError ? AsyncError(result.error!, result.stackTrace!) : const AsyncData(null);
    return result.valueOrNull;
  }

  Future<void> signOut() async {
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => _authService.signOut());
  }
}

final authControllerProvider =
    StateNotifierProvider<AuthController, AsyncValue<void>>((ref) {
  return AuthController(ref.watch(authServiceProvider));
});
