import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';
import '../../../providers/room_provider.dart';

/// Student's view of a joined room — functions like a Google Classroom
/// feed (spec §3). Quick links to attendance, assignments, exams, content
/// for this room. Chat/messages tile only shows if teacher enabled it.
class RoomFeedScreen extends ConsumerWidget {
  const RoomFeedScreen({super.key, required this.roomId});

  final String roomId;

  String _path(String template) => template.replaceFirst(':roomId', roomId);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final roomAsync = ref.watch(roomByIdProvider(roomId));

    return Scaffold(
      appBar: AppBar(title: const Text('Room')),
      body: roomAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (err, _) => Center(child: Text('Failed to load room: $err')),
        data: (room) {
          return ListView(
            padding: const EdgeInsets.all(16),
            children: [
              Card(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(room.name,
                          style: Theme.of(context).textTheme.titleLarge),
                      if (room.subject != null) Text(room.subject!),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 16),
              _FeatureTile(
                icon: Icons.event_available_outlined,
                label: 'My Attendance',
                onTap: () => context.push(_path(RouteNames.attendanceView)),
              ),
              // Chat only shown if the teacher has enabled it (spec §2.2, §3).
              if (room.chatEnabled)
                _FeatureTile(
                  icon: Icons.chat_bubble_outline,
                  label: 'Messages & Polls',
                  onTap: () => context.push(_path(RouteNames.messaging)),
                ),
              _FeatureTile(
                icon: Icons.assignment_outlined,
                label: 'Assignments',
                onTap: () {
                  // Assignment list is nested under this room; the
                  // assignmentId-specific route is pushed once an
                  // assignment is selected from that list.
                  context.push(_path(RouteNames.assignments));
                },
              ),
              _FeatureTile(
                icon: Icons.bar_chart_outlined,
                label: 'My Performance',
                onTap: () => context.push(_path(RouteNames.examPerformance)),
              ),
              // Leaderboard only shown if the teacher has enabled it (spec §2.7).
              if (room.leaderboardEnabled)
                _FeatureTile(
                  icon: Icons.leaderboard_outlined,
                  label: 'Leaderboard',
                  onTap: () => context.push(_path(RouteNames.leaderboard)),
                ),
            ],
          );
        },
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({
    required this.icon,
    required this.label,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: const EdgeInsets.only(bottom: 8),
      child: ListTile(
        leading: Icon(icon),
        title: Text(label),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}
