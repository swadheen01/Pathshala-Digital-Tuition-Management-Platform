import 'package:flutter/material.dart';

/// Raw color values referenced outside of ThemeData — e.g. status
/// colors for attendance/payment states that don't come from the
/// Material color scheme. Prefer Theme.of(context).colorScheme for
/// anything theme-related; use these only for fixed semantic colors.
class AppColors {
  AppColors._();

  static const Color success = Color(0xFF2E7D32);
  static const Color warning = Color(0xFFF9A825);
  static const Color danger = Color(0xFFC62828);
  static const Color info = Color(0xFF1565C0);
}
