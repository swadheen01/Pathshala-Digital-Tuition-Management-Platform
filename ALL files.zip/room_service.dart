import 'dart:math';

import 'package:supabase_flutter/supabase_flutter.dart';

import '../core/config/supabase_config.dart';
import '../models/room_member_model.dart';
import '../models/room_model.dart';

/// Handles all Supabase calls related to Tuition Rooms (spec §2.1, §2.5).
class RoomService {
  RoomService({SupabaseClient? client})
      : _client = client ?? SupabaseConfig.client;

  final SupabaseClient _client;

  static const _joinCodeChars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789'; // no O/0/I/1

  String _generateJoinCode({int length = 6}) {
    final rand = Random.secure();
    return List.generate(
      length,
      (_) => _joinCodeChars[rand.nextInt(_joinCodeChars.length)],
    ).join();
  }

  /// Creates a new room for the currently signed-in teacher.
  /// Retries a couple of times on the (rare) join-code collision.
  Future<RoomModel> createRoom({
    required String name,
    String? subject,
    String? description,
    List<int> classDays = const [],
  }) async {
    final teacherId = _client.auth.currentUser?.id;
    if (teacherId == null) {
      throw StateError('Must be signed in to create a room.');
    }

    for (var attempt = 0; attempt < 3; attempt++) {
      try {
        final response = await _client
            .from('rooms')
            .insert({
              'teacher_id': teacherId,
              'name': name,
              'subject': subject,
              'description': description,
              'join_code': _generateJoinCode(),
              'class_days': classDays,
            })
            .select()
            .single();
        return RoomModel.fromJson(response);
      } on PostgrestException catch (e) {
        // Unique violation on join_code — retry with a new code.
        if (e.code == '23505' && attempt < 2) continue;
        rethrow;
      }
    }
    throw StateError('Could not generate a unique join code. Try again.');
  }

  /// Rooms owned by the current teacher.
  Future<List<RoomModel>> fetchTeacherRooms() async {
    final teacherId = _client.auth.currentUser?.id;
    if (teacherId == null) return [];

    final response = await _client
        .from('rooms')
        .select()
        .eq('teacher_id', teacherId)
        .order('created_at', ascending: false);

    return (response as List)
        .map((row) => RoomModel.fromJson(row as Map<String, dynamic>))
        .toList();
  }

  /// Rooms the current student has joined.
  Future<List<RoomModel>> fetchStudentRooms() async {
    final studentId = _client.auth.currentUser?.id;
    if (studentId == null) return [];

    final response = await _client
        .from('room_members')
        .select('rooms(*)')
        .eq('student_id', studentId);

    return (response as List)
        .map((row) =>
            RoomModel.fromJson(row['rooms'] as Map<String, dynamic>))
        .toList();
  }

  /// Student joins a room using the teacher-provided join code (spec §2.1).
  /// Calls the join_room RPC (see 0002_rooms.sql) so we don't need a
  /// broad "anyone can read any room" RLS policy just for lookups.
  Future<RoomModel> joinRoomByCode(String joinCode, {String? rollNumber}) async {
    try {
      final response = await _client.rpc('join_room', params: {
        'p_join_code': joinCode.trim().toUpperCase(),
        'p_roll_number': rollNumber,
      });
      return RoomModel.fromJson(response as Map<String, dynamic>);
    } on PostgrestException catch (e) {
      if (e.message.contains('Invalid join code')) {
        throw Exception('Invalid join code. Please check and try again.');
      }
      rethrow;
    }
  }

  Future<RoomModel> fetchRoomById(String roomId) async {
    final response =
        await _client.from('rooms').select().eq('id', roomId).single();
    return RoomModel.fromJson(response);
  }

  /// Update room settings — schedule, chat toggle, leaderboard toggle.
  Future<RoomModel> updateRoom(
    String roomId, {
    String? name,
    String? subject,
    String? description,
    bool? chatEnabled,
    bool? leaderboardEnabled,
    List<int>? classDays,
  }) async {
    final updates = <String, dynamic>{
      if (name != null) 'name': name,
      if (subject != null) 'subject': subject,
      if (description != null) 'description': description,
      if (chatEnabled != null) 'chat_enabled': chatEnabled,
      if (leaderboardEnabled != null)
        'leaderboard_enabled': leaderboardEnabled,
      if (classDays != null) 'class_days': classDays,
    };

    final response = await _client
        .from('rooms')
        .update(updates)
        .eq('id', roomId)
        .select()
        .single();

    return RoomModel.fromJson(response);
  }

  /// Roster of students in a room, joined with profile info (spec §2.1).
  Future<List<RoomMemberWithProfile>> fetchRoomMembers(String roomId) async {
    final response = await _client
        .from('room_members')
        .select('*, profiles(full_name, email, avatar_url)')
        .eq('room_id', roomId)
        .order('joined_at');

    return (response as List)
        .map((row) =>
            RoomMemberWithProfile.fromJson(row as Map<String, dynamic>))
        .toList();
  }

  Future<void> removeMember(String roomId, String studentId) async {
    await _client
        .from('room_members')
        .delete()
        .eq('room_id', roomId)
        .eq('student_id', studentId);
  }

  Future<void> deleteRoom(String roomId) async {
    await _client.from('rooms').delete().eq('id', roomId);
  }
}
