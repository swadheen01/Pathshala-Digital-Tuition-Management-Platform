import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';

import '../../../core/routes/route_names.dart';
import '../../../core/utils/validators.dart';
import '../../../models/user_model.dart';
import '../../../providers/auth_provider.dart';

/// Final step of signup: captures full name + role-specific fields
/// (class/grade, institution — spec §1) and writes the profile row.
///
/// Expects the chosen UserRole via GoRouter's `extra`:
///   context.push(RouteNames.profileSetup, extra: UserRole.student);
class ProfileSetupScreen extends ConsumerStatefulWidget {
  const ProfileSetupScreen({super.key, required this.role});

  final UserRole role;

  @override
  ConsumerState<ProfileSetupScreen> createState() =>
      _ProfileSetupScreenState();
}

class _ProfileSetupScreenState extends ConsumerState<ProfileSetupScreen> {
  final _formKey = GlobalKey<FormState>();
  final _nameController = TextEditingController();
  final _classGradeController = TextEditingController();
  final _institutionController = TextEditingController();

  @override
  void dispose() {
    _nameController.dispose();
    _classGradeController.dispose();
    _institutionController.dispose();
    super.dispose();
  }

  bool get _needsClassGrade => widget.role == UserRole.student;

  Future<void> _handleSubmit() async {
    if (!_formKey.currentState!.validate()) return;

    final profile = await ref.read(authControllerProvider.notifier).completeProfile(
          fullName: _nameController.text.trim(),
          role: widget.role,
          classGrade: _needsClassGrade
              ? _classGradeController.text.trim()
              : null,
          institution: _institutionController.text.trim().isEmpty
              ? null
              : _institutionController.text.trim(),
        );

    if (!mounted) return;

    if (profile == null) {
      final state = ref.read(authControllerProvider);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Could not save profile: ${state.error}')),
      );
      return;
    }

    ref.invalidate(currentProfileProvider);

    switch (widget.role) {
      case UserRole.teacher:
        context.go(RouteNames.teacherDashboard);
      case UserRole.admin:
        context.go(RouteNames.adminDashboard);
      case UserRole.parent:
        context.go(RouteNames.parentDashboard);
      case UserRole.student:
        context.go(RouteNames.studentDashboard);
    }
  }

  @override
  Widget build(BuildContext context) {
    final authState = ref.watch(authControllerProvider);
    final isLoading = authState.isLoading;

    return Scaffold(
      appBar: AppBar(title: const Text('Set Up Your Profile')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(labelText: 'Full Name'),
                  validator: (v) => Validators.required(v, fieldName: 'Name'),
                  enabled: !isLoading,
                ),
                const SizedBox(height: 16),
                if (_needsClassGrade) ...[
                  TextFormField(
                    controller: _classGradeController,
                    decoration: const InputDecoration(
                      labelText: 'Class / Grade',
                      hintText: 'e.g. Class 9',
                    ),
                    validator: (v) =>
                        Validators.required(v, fieldName: 'Class/Grade'),
                    enabled: !isLoading,
                  ),
                  const SizedBox(height: 16),
                ],
                TextFormField(
                  controller: _institutionController,
                  decoration: const InputDecoration(
                    labelText: 'Institution (optional)',
                    hintText: 'School / college name',
                  ),
                  enabled: !isLoading,
                ),
                const SizedBox(height: 24),
                ElevatedButton(
                  onPressed: isLoading ? null : _handleSubmit,
                  child: isLoading
                      ? const SizedBox(
                          height: 20,
                          width: 20,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Text('Continue'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
